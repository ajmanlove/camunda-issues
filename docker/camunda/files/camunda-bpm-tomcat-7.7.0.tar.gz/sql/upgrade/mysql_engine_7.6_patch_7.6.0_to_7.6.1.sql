alter table ACT_RU_EVENT_SUBSCR
  modify ACTIVITY_ID_ varchar(255);