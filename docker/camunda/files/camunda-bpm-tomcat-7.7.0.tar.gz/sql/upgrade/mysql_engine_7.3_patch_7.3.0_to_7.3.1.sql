alter table ACT_HI_JOB_LOG
  modify ACT_ID_ varchar(255);
