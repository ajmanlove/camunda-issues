--https://app.camunda.com/jira/browse/CAM-7442
drop index ACT_IDX_JOB_HANDLER on ACT_RU_JOB;